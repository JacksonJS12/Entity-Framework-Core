﻿namespace Boardgames.Common;

public class ValidationConstants
{
    //Boardgame
    public const int BoardgameNameMaxLength = 20;
    public const int BoardgameRatingMaxLength = 10;
    public const int BoardgameYearPublishedMaxLength = 2023;

    //Seller
    public const int SellerNameMaxLength = 20;
    public const int SellerAddressMaxLength = 30;
}