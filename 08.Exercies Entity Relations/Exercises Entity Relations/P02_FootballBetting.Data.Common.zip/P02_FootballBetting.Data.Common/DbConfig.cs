﻿namespace P02_FootballBetting.Data.Common
{
    public static class DbConfig
    {
        // ReSharper disable once InconsistentNaming
        public const string ConnectionString =
            @"Server=DESKTOP-2ASBARL\SQLEXPRESS;Database=Bet388;Integrated Security=True;Encrypt=False;";
    }
}