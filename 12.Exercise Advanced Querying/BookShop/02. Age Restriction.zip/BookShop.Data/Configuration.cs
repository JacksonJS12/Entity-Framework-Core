﻿namespace BookShop.Data;

internal class Configuration
{
    internal static string ConnectionString
        => "Server=DESKTOP-CPVUD3U;Database=BookShop;Integrated Security=True;";
}

