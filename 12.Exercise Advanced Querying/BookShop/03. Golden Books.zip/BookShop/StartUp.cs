﻿using BookShop.Models.Enums;

namespace BookShop;
using Data;
using Initializer;

public class StartUp
{
    public static void Main()
    {
        var dbContext = new BookShopContext();
        //DbInitializer.ResetDatabase(db);

        //string ageRestrictionInput = Console.ReadLine();
        //string result = GetBooksByAgeRestriction(dbContext, ageRestrictionInput);
        string result = GetGoldenBooks(dbContext);

        Console.WriteLine(result);
    }

    public static string GetBooksByAgeRestriction(BookShopContext context, string command)
    {
        AgeRestriction ageRestriction;

        var isParseSuccess = Enum.TryParse<AgeRestriction>(command, true, out ageRestriction);

        if (!isParseSuccess)
        {
            return string.Empty;
        }

        string[] bookTitles = context
            .Books
            .Where(b => b.AgeRestriction == ageRestriction)
            .Select(b => b.Title)
            .OrderBy(t => t)
            .ToArray();

        return string.Join(Environment.NewLine, bookTitles);
    }

    public static string GetGoldenBooks(BookShopContext dbContext)
    {
        string[] bookTitles = dbContext.Books
            .Where(b => b.EditionType == EditionType.Gold &&
                        b.Copies < 5000)
            .OrderBy(b => b.BookId)
            .Select(b => b.Title)
            .ToArray();

        return String.Join(Environment.NewLine, bookTitles);
            
    }
}



