﻿namespace BookShop.Data;

internal class Configuration
{
    internal static string ConnectionString
        => "Server=DESKTOP-SV9GMAA;Database=BookShop;Integrated Security=True;";
}

