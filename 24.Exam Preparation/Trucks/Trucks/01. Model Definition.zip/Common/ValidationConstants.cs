﻿namespace Trucks.Common
{
    public class ValidationConstants
    {
        //Truck
        public const int RegistrationNumberLength = 8;
        public const int VinNumberLength = 18;

        //Client
        public const int ClientNameLength = 40;
        public const int ClientNationalityLength = 40;

        //Despatcher
        public const int DespatcherNameLength = 40;
    }
}